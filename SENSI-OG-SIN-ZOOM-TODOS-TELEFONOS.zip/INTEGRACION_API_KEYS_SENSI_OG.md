# SENSI OG — Panel web y app conectados a la misma API

## Qué se integró
- El panel web original ahora se sirve desde `/keys` en el mismo servidor.
- Las Keys se generan, consultan y revocan en PostgreSQL, no en `localStorage`.
- La app iOS consulta `/api/activate` en el mismo servicio.
- Duración (horas/días), máximo de dispositivos y revocación se almacenan en el servidor.
- El endpoint `/health` permite comprobar el servicio.

## Publicación necesaria (no se ha hecho desde este ZIP)
1. Sube este ZIP a un repositorio GitHub.
2. En Render crea un Blueprint desde el repositorio y acepta `render.yaml`.
3. Render creará el servicio `sensi-og-keys` y PostgreSQL. Configura `ADMIN_KEY` con una contraseña larga y privada.
4. Espera a que `/health` responda `{"ok":true}`. El panel estará en `https://sensi-og-keys.onrender.com/keys`. Si Render asigna otro hostname, cambia `PantherAPIBaseURL` en `ThreeOneOSFive/Info.plist` por ese HTTPS y vuelve a compilar la app.
5. Abre `/keys`, pulsa conectar e introduce el mismo `ADMIN_KEY`.

## Importante
- No publiques ni compartas `ADMIN_KEY`, `DATABASE_URL` ni tokens de Telegram.
- La API no queda activa hasta desplegar el servicio y crear la base de datos.
- El proyecto no fue compilado con Xcode ni desplegado en Render en este entorno.
- El servicio usa PostgreSQL; no es posible validar Keys entre dispositivos con `localStorage` del navegador.
